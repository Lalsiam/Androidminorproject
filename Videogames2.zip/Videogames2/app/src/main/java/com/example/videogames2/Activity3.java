package com.example.videogames2;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

public class Activity3 extends AppCompatActivity {
    private Button button3;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_3);
        Button butt = findViewById(R.id.button4);
        butt.setOnClickListener(new View.OnClickListener() {
                                    @Override
                                    public void onClick(View v) {
                                        Toast.makeText(Activity3.this, "People who play video games for long periods of time tend to report feeling happier than those who do not, a study has indicated. ", Toast.LENGTH_LONG).show();
                                    }
                                });
        button3 = (Button)findViewById(R.id.button3);
        button3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openActivity4();
            }
        });


    }
    public void openActivity4()
    {
        Intent intent = new Intent(this, Activity4.class);
        startActivity(intent);
    }
}